<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Seasons extends Model
{
    protected $table = 'seasons';
    protected $fillable = [
        'name','user_id','updated_at',
    ];
}
