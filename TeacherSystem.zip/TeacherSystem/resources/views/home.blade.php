@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{$Seasons}}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div class="row">
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Time Table</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Event</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Award</a>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Activities</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Email</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">COMM Record</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
