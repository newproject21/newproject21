<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e($Seasons); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Time Table</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Event</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Award</a>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Activities</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">Email</a>
                        </div>
                        <div class="col-md-3">
                            <a class="linkClass" href="#">COMM Record</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TeacherSystem\resources\views/home.blade.php ENDPATH**/ ?>